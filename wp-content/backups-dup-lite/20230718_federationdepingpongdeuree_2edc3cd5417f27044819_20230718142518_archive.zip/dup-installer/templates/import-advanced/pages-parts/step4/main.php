<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

dupxTplRender('pages-parts/step4/actions/admin-login-button');
dupxTplRender('pages-parts/step4/important-final-notice');
dupxTplRender('pages-parts/step4/actions/recovery-point-button');
dupxTplRender('pages-parts/step4/installer-result-summary');
dupxTplRender('pages-parts/step4/final-review-actions');
dupxTplRender('pages-parts/step4/full-report');
